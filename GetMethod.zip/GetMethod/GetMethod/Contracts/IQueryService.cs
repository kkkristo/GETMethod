﻿using GetMethod.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Contracts
{
    public interface IQueryService
    {
        public QueryParameters SetParameters();

        public string GetBearerToken();

        public StringBuilder BuildQueryString(QueryParameters queryParams);

         public IEnumerable<string> GetOrdersIdsFromDb();   

    }
}
