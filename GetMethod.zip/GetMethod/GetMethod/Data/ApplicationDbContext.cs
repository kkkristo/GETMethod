﻿using GetMethod.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Data
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<OrderCost>OrderCosts { get; set; }
        public DbSet<OfferCost>OfferCosts { get; set; }
        public DbSet<OrdersTable>OrdersTable { get; set; }

        //public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        //{
            
        //}
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase("CostsDb");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<OrdersTable>().HasData(
            new OrdersTable { Id = 1, ErpOrderId = 234, InvoiceId = 23425, OrderId = "09f0b4cc-7880-11e9-8f9e-2a86e4085a59", StoreId = 3245 },
            new OrdersTable { Id = 2, ErpOrderId = 178, InvoiceId = 23455, OrderId = "04b09fdd-7812-9e11-e98f-085a592a86e4", StoreId = 213 }
        );
        }
    }
}
