﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Mocks
{
    public static class SD
    {
        public const string raw200Response =
            @"
                {
                  ""billingEntries"": [
                    {
                      ""id"": ""09f0b4cc-7880-11e9-8f9e-2a86e4085a59"",
                      ""occurredAt"": ""2019-05-08T09:45:32.818Z"",
                      ""type"": {
                        ""id"": ""LIS"",
                        ""name"": ""Listing fee""
                      },
                      ""offer"": {
                        ""id"": ""12345"",
                        ""name"": ""offer name""
                      },
                      ""value"": {
                        ""amount"": ""100.00"",
                        ""currency"": ""PLN""
                      },
                      ""tax"": {
                        ""percentage"": ""0"",
                        ""annotation"": ""OUT_OF_SCOPE""
                      },
                      ""balance"": {
                        ""amount"": ""100.00"",
                        ""currency"": ""PLN""
                      },
                      ""order"": {
                        ""id"": ""09f0b4cc-7880-11e9-8f9e-2a86e40-1111""
                      }
                        },
                                {
                      ""id"": ""aaaaa-bbbbb-cccccc"",
                      ""occurredAt"": ""2019-05-08T09:45:32.818Z"",
                      ""type"": {
                        ""id"": ""SUC"",
                        ""name"": ""Success sale fee""
                      },
                      ""offer"": {
                        ""id"": ""7878"",
                        ""name"": ""offer name""
                      },
                      ""value"": {
                        ""amount"": ""78.20"",
                        ""currency"": ""PLN""
                      },
                      ""tax"": {
                        ""percentage"": ""23"",
                        ""annotation"": ""OUT_OF_SCOPE""
                      },
                      ""balance"": {
                        ""amount"": ""578.12"",
                        ""currency"": ""PLN""
                      },
                      ""order"": {
                        ""id"": ""2a86e40-7880-11e9-8f9e-09f0b4cc-2222""
                      }
                        }

                    ]
                }";


        public const string Raw422Response =
        @"
        {
          ""errors"": [
            {
              ""code"": ""NotAcceptableException"",
              ""details"": """",
              ""message"": ""Not acceptable representation requested. Please check 'Accept' request header"",
              ""path"": """",
              ""userMessage"": ""The request contains incorrect data. Contact the author of the application."",
              ""metadata"": {
                ""productId"": ""13232515"" }             
            }
          ]
        }
        ";

        public static List<string> ordersList = new()
            {
                "23123231-123123-123213-123",
                "21323-3434345-565656",
                "6565655-7879878-898987"
            };

    }
}
