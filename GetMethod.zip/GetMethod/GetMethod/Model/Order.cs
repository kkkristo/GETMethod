﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Model
{
    public class Order
    {
        // to look by
        [JsonProperty("id")]
        public string OrderId { get; set; }

        public string? ErpOrderId { get; set; }

        public string? InvoiceId { get; set; }

        public string StoreId { get; set; }

    }
}
