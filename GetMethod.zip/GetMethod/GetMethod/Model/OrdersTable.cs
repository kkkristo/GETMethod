﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Model
{
    public class OrdersTable
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(45)]
        public string OrderId { get; set; }

        public int? ErpOrderId { get; set; }

        public int? InvoiceId { get; set; }

        public int StoreId { get; set; }        

    }
}
