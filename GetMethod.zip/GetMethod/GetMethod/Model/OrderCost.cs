﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Model
{
    public class OrderCost
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        public string Order_Id { get; set; }
        [Required]
        public string BillingType_Id { get; set; }
        [Required]
        public string BillingType_Name { get; set; }
        [Required]
        public decimal BillingValue_Amount { get; set; }
        [Required]
        public string BillingValue_Currency { get; set; }
        [Required]
        public int Tax_Percentage { get; set; }
        public string? Tax_Annotation { get; set; }
        
    }
}
