﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Model
{
    public class Tax
    {
        [JsonProperty("percentage")]
        public string Percentage { get; set; }
        [JsonProperty("annotation")]
        public string Annotation { get; set; }
    }
}
