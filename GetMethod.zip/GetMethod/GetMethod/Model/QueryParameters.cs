﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Model
{

    public class QueryParameters
    {
        public string? MarketplaceId { get; set; }

        public string? OccurredAtGte { get; set; }

        public string? OccurredAtLte { get; set; }

        public List<string>? TypeIds { get; set; } = new();

        public string? OfferId { get; set; }

        public string? OrderId { get; set; }

        public string? Limit { get; set; }

        public string? Offset { get; set; }
    }
}
