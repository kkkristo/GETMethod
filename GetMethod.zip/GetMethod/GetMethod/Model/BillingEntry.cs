﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Model
{
    public class BillingEntry
    {
        public string Id { get; set; }
        public DateTime OccuredAt { get; set; }
        public string BillingType_Id { get; set; }
        public string BillingType_Name { get; set; }
        public string Offer_Id { get; set; }
        public string Offer_Name { get; set; }
        public decimal BillingValue_Amount { get; set; }
        public string BillingValue_Currency { get; set; }
        public int Tax_Percentage { get; set; }
        public string Tax_Annotation { get; set; }
        public decimal Balance_Amount { get; set; }
        public string Balance_Currency { get; set; }
        public string Order_Id { get; set; }
    }
}
