﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Model
{
   
        public class RootObject
        {
            [JsonProperty("billingEntries")]
            public List<Response> BillingEntries { get; set; }
        }
   
}
