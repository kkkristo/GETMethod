﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace GetMethod.Model
{
    public class Response
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("occurredAt")]
        public DateTime OccurredAt { get; set; }

        [JsonProperty("type")]
        public BillingType Type { get; set; }

        [JsonProperty("offer")]
        public Offer Offer { get; set; }

        [JsonProperty("value")]
        public BillingValue Value { get; set; }

        [JsonProperty("tax")]
        public Tax Tax { get; set; }

        [JsonProperty("balance")]
        public Balance Balance { get; set; }

        [JsonProperty("order")]
        public Order Order { get; set; }
    }
}
