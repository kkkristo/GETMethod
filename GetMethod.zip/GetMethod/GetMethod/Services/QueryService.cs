﻿using GetMethod.Contracts;
using GetMethod.Data;
using GetMethod.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetMethod.Services
{
    public class QueryService : IQueryService
    {
        public IEnumerable<string> GetOrdersIdsFromDb()
        {
            List<string> idsOfOrders = new();
            try
            {
                using (ApplicationDbContext db = new())
                {
                    db.Database.EnsureCreated();                    
                    idsOfOrders = db.OrdersTable.Select(x => x.OrderId).ToList();
                }
            }
            catch (Exception)
            {
            }

            return idsOfOrders;
        }

        //Pobranie parametrów od użytkownika do metody GET
        public QueryParameters SetParameters()
        {
            QueryParameters parameters = new();


            Console.WriteLine("\nEnter marketplaceId, press \"enter\" for OK/skip");
            parameters.MarketplaceId = Console.ReadLine();

            Console.WriteLine("\nEnter FROM Date & Time (occurredAt.gte)\n" +
                "as YYYY-MM-DD and optionally HH:MM:SS, press \"enter\" for OK/skip");
            parameters.OccurredAtGte = Console.ReadLine();
            try
            {
                parameters.OccurredAtGte = parameters.OccurredAtGte.Trim();
                parameters.OccurredAtGte = parameters.OccurredAtGte.Replace(" ", "");
                parameters.OccurredAtGte = parameters.OccurredAtGte.Insert(10, "T");
                if (parameters.OccurredAtGte.Length > 10)
                {
                    parameters.OccurredAtGte = parameters.OccurredAtGte.Insert(16, ":00.000Z");
                    parameters.OccurredAtGte = parameters.OccurredAtGte.Remove(24);
                }
                else
                {
                    parameters.OccurredAtGte = parameters.OccurredAtGte.Insert(11, "00:00:000Z");
                }
            }
            catch (Exception)
            {
            }

            Console.WriteLine("\nEnter TO Date & Time (occurredAt.lte)\n " +
                        "as YYYY-MM-DD and optionally HH:MM:SS, press \"enter\" for OK/skip");
            parameters.OccurredAtLte = Console.ReadLine();
            try
            {
                parameters.OccurredAtLte = parameters.OccurredAtLte.Trim();
                parameters.OccurredAtLte = parameters.OccurredAtLte.Replace(" ", "");
                parameters.OccurredAtLte = parameters.OccurredAtLte.Insert(10, "T");
                if (parameters.OccurredAtLte.Length > 10)
                {
                    parameters.OccurredAtLte = parameters.OccurredAtLte.Insert(16, ":00.000Z");
                    parameters.OccurredAtLte = parameters.OccurredAtLte.Remove(24);
                }
                else
                {
                    parameters.OccurredAtLte = parameters.OccurredAtLte.Insert(11, "00:00:000Z");
                }
            }
            catch (Exception)
            {
            }

            Console.WriteLine("\nEnter type.id or ids separated by comma, press \"enter\" for OK/skip");
            string inputedTypeIds = Console.ReadLine();
            inputedTypeIds = inputedTypeIds.Trim();
            inputedTypeIds = inputedTypeIds.Replace(" ", "");
            string[] typeIdsArray = inputedTypeIds.Split(",", StringSplitOptions.RemoveEmptyEntries);


            foreach (string typeId in typeIdsArray)
            {
                parameters.TypeIds.Add(typeId);
            };

            Console.WriteLine("\nEnter offer.id, press \"enter\" for OK/skip");
            parameters.OfferId = Console.ReadLine();

            //Console.WriteLine("Enter order.id")->NO, this is from foreach loop;
            //orderId = Console.ReadLine();

            Console.WriteLine("\nEnter limit of returned operations, default=100, press \"enter\" for OK/skip");
            parameters.Limit = Console.ReadLine();

            Console.WriteLine("\nEnter offset: Index of the first returned payment operation from all search results. Press \"enter\" for OK/skip");
            parameters.Offset = Console.ReadLine();

            return parameters;
        }

        public StringBuilder BuildQueryString(QueryParameters queryParams)
        {
            // Building query string from params
            // 
            StringBuilder sb = new();
            string baseUrl = "https://api.allegro.pl/billing/billing-entries?";
            sb.Append(baseUrl);

            if (!string.IsNullOrEmpty(queryParams.MarketplaceId))
            {
                sb.Append($"marketplaceId={queryParams.MarketplaceId}&");
            }

            if (!string.IsNullOrEmpty(queryParams.OccurredAtGte))
            {
                sb.Append($"occurredAt.gte={queryParams.OccurredAtGte}&");
            }

            if (!string.IsNullOrEmpty(queryParams.OccurredAtLte))
            {
                sb.Append($"occurredAt.lte={queryParams.OccurredAtLte}&");
            }

            for (int i = 0; i < queryParams.TypeIds.Count; i++)
            {
                sb.Append($"type.id={queryParams.TypeIds[i]}&");
            }

            if (!string.IsNullOrEmpty(queryParams.OfferId))
            {
                sb.Append($"offer.id={queryParams.OfferId}&");
            }

            if (!string.IsNullOrEmpty(queryParams.Limit))
            {
                sb.Append($"limit={queryParams.Limit}&");
            }

            if (!string.IsNullOrEmpty(queryParams.Offset))
            {
                sb.Append($"offset={queryParams.Offset}&");
            }
            return sb;
        }

        public string GetBearerToken()
        {
            Console.WriteLine();
            Console.WriteLine("Paste your token below, then press \"ENTER\":");
            string token = Console.ReadLine();
            return token;
        }
    }
}
