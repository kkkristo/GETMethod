﻿using GetMethod.Contracts;
using GetMethod.Data;
using GetMethod.Mocks;
using GetMethod.Model;
using GetMethod.Services;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;



namespace GetMethod
{
    internal class Program()
    {
        public static async Task Main(string[] args)
        {
            Console.WriteLine("          >>>>>>>>> GET Billing Entries 1.0 <<<<<<<<< \n" +
                              "                            by KrzySzko");
            Console.WriteLine("\n");
            Console.WriteLine("Info #1: I assumed OrdersTable is already in inMemory-dbContext and has 2 initial entries");
            Console.WriteLine("Info #2: In OFFLINE mode example server response returns 2 billing entries per request ");
            Console.WriteLine("Info #3: Both modes (online/offline) accept query parameters from user");
            Console.WriteLine("\n");
            var serviceProvider = new ServiceCollection()
                .AddSingleton<IQueryService, QueryService>()
                .BuildServiceProvider();
            var queryService = serviceProvider.GetService<IQueryService>();

            //Choose online or offline version:

            Console.WriteLine("PRESS 1 to select ONLINE mode, any key to select OFFLINE mode, \"enter\" for OK");
            string onoffline = Console.ReadLine();
            onoffline = onoffline.Trim();

            //Getting list of orders for GET method
            //Assumed the same dbContext is used for Orders and for query-result data to store
            //In online mode it's possiblle to enter example order.id
            //List<string> ordersList = new();

            string orderId = string.Empty;
            if (onoffline == "1")
            {
                Console.WriteLine("In online mode you can enter single real-world order-id below.\n" +
                    "If left empty, programm will use example ids to build the query");
                orderId = Console.ReadLine();
            }

            List<string> ordersList = new List<string>();
            if (!string.IsNullOrEmpty(orderId))
            {
                ordersList.Add(orderId);
            }
            else
            {
                ordersList = queryService.GetOrdersIdsFromDb().ToList();
            }
            if (string.IsNullOrEmpty(orderId))
            {
                Console.WriteLine($"\nNo order id entered or offline mode. \nFollowing orders received from in-memory dbContext. Orders count: {ordersList.Count()}");
            }
            foreach (var order in ordersList)
            {
                Console.WriteLine($"Order number: {ordersList.IndexOf(order) + 1}, order id: {order}");
            }
            Console.WriteLine();

            //Getting bearer token from user
            string bearerToken = onoffline == "1" ? queryService.GetBearerToken() : string.Empty;

            //Getting additional parameters from user for GET method:
            var queryParams = queryService.SetParameters();

            // Building query string from params, without order.id
            var queryString = queryService.BuildQueryString(queryParams);

            //Create container for successfull responses
            List<BillingEntry> billingEntriesList = new();

            //GET Billing Entries for each order
            foreach (var order in ordersList)
            {
                // Adding parameter "order.id" to GET query
                StringBuilder completeUrl = new(queryString.ToString());
                completeUrl.Append("&order.id=" + order);
                completeUrl.Replace("&&", "&");
                string url = completeUrl.ToString();

                Console.WriteLine();
                Console.WriteLine($"Query string no. {ordersList.IndexOf(order) + 1}: \n{url}");

                // http client GET method with parameters
                try
                {   // ONLINE or OFFLINE example response body from allegro.pl OR from Mocks.SD class in app
                    string jsonResponse = onoffline == "1" ? await GetBillingEntriesAsync(url, bearerToken) : SD.raw200Response;

                    RootObject root = JsonConvert.DeserializeObject<RootObject>(jsonResponse);

                    // Convert response to Entity object with all OR selected props
                    foreach (var entry in root.BillingEntries)
                    {
                        BillingEntry billingEntry = new()
                        {
                            Order_Id = entry.Order.OrderId,
                            //Id = entry.Id,
                            //OccuredAt = entry.OccurredAt,
                            BillingType_Id = entry.Type.Id,
                            BillingType_Name = entry.Type.Name,
                            Offer_Id = entry.Offer.Id,
                            BillingValue_Amount = decimal.Parse(entry.Value.Amount, new CultureInfo("en-US")),
                            BillingValue_Currency = entry.Value.Currency,
                            Tax_Percentage = int.Parse(entry.Tax.Percentage),
                            Tax_Annotation = entry.Tax.Annotation,
                            //Balance_Amount = decimal.Parse(entry.Value.Amount, new CultureInfo("en-US")),
                            //Balance_Currency = entry.Value.Currency,
                        };

                        billingEntriesList.Add(billingEntry);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error ocurred:\n {ex.Message}");
                }
            }

            using (ApplicationDbContext db = new ApplicationDbContext())
            {
                foreach (var entry in billingEntriesList)
                {
                    var orderCost = new OrderCost
                    {
                        Order_Id = entry.Order_Id,
                        BillingType_Id = entry.BillingType_Id,
                        BillingType_Name = entry.BillingType_Name,
                        BillingValue_Amount = entry.BillingValue_Amount,
                        BillingValue_Currency = entry.BillingValue_Currency,
                        Tax_Annotation = entry.Tax_Annotation,
                        Tax_Percentage = entry.Tax_Percentage
                    };

                    if (!string.IsNullOrEmpty(entry.Offer_Id))
                    {
                        var offerCost = new OfferCost
                        {
                            Offer_Id = entry.Offer_Id,
                            BillingType_Id = entry.BillingType_Id,
                            BillingType_Name = entry.BillingType_Name,
                            BillingValue_Amount = entry.BillingValue_Amount,
                            BillingValue_Currency = entry.BillingValue_Currency,
                            Tax_Annotation = entry.Tax_Annotation,
                            Tax_Percentage = entry.Tax_Percentage
                        };

                        db.OfferCosts.Add(offerCost);
                    }

                    db.OrderCosts.Add(orderCost);
                    db.SaveChanges();
                }
            }

            if (billingEntriesList.Count > 0)
            {
                Console.WriteLine("\n\n ORDERS COSTS Database:\n");
                Console.WriteLine("Received data:\n");

                using (ApplicationDbContext dbContext = new ApplicationDbContext())

                {
                    var orderCosts = dbContext.OrderCosts.ToList();

                    foreach (var oc in orderCosts)
                    {
                        Console.WriteLine($"Order id: {oc.Order_Id}, Billing amount:{oc.BillingValue_Amount} {oc.BillingValue_Currency}, " +
                        $"Billing type: {oc.BillingType_Id}, {oc.BillingType_Name}, Tax %: {oc.Tax_Percentage}, Tax info: {oc.Tax_Annotation}");
                    }

                    if (billingEntriesList.Any(e => e.Offer_Id.Length > 0))
                    {
                        Console.WriteLine("\n\n OFFERS COSTS Database:\n");
                        Console.WriteLine("Received data:\n");
                        var offerCosts = dbContext.OfferCosts.ToList();

                        foreach (var oc in offerCosts)
                        {
                            Console.WriteLine($"Offer id: {oc.Offer_Id}, Billing amount:{oc.BillingValue_Amount} {oc.BillingValue_Currency}, " +
                            $"Billing type: {oc.BillingType_Id}, {oc.BillingType_Name}, Tax %: {oc.Tax_Percentage}, Tax info: {oc.Tax_Annotation}");
                        }
                    }
                }
            }

            Console.WriteLine($"\n About to finish... Thank you for your time.");
            Console.ReadLine();
        }

        public static async Task<string> GetBillingEntriesAsync(string url, string bearerToken)
        {
            using (HttpClient client = new())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.allegro.public.v1+json"));
                client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/vnd.allegro.public.v1+json");

                HttpResponseMessage response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode();

                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    return responseBody;
                }
                else
                {
                    string responseBody = $"Error occured - {(int)response.StatusCode} : {response.ReasonPhrase} ";
                    return responseBody;
                }
            }
        }
    }




}
